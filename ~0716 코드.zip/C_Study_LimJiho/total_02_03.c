//Chapter2_���չ��� 3
/*
#include <stdio.h>

int main(void) {
    int n, i;
    int count = 0;

    for (n = 2; count < 10; n++) {
        for (i = 2; i <= n; i++) {
            if (i == n) {
                printf("%d ", n);
                count++;
            }

            if (n % i == 0)
                break;
        }
    }

    return 0;
}*/