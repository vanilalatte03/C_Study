//Chapter2_���չ��� 4
/*
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) {
    char i;
    int num1, num2;

    printf("�ǿ����� 1 : ");
    scanf("%d", &num1);

    printf("������ : ");
    scanf(" %c", &i);

    printf("�ǿ����� 2 : ");
    scanf("%d", &num2);

    switch (i){
        case '+':
            printf("%d + %d = %d", num1, num2, num1 + num2);
            break;
        case '-':
            printf("%d - %d = %d", num1, num2, num1 - num2);
            break;
        case '*':
            printf("%d * %d = %d", num1, num2, num1 * num2);
            break;
        case '/':
            printf("%d / %d = %d", num1, num2, num1 / num2);
            break;
    }

    return 0;
}*/