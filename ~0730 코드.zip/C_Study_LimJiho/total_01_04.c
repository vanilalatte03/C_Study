//Chapter1_���չ��� 4
/*
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main() {
    double num;
    int num2;

    printf("NUM : ");
    scanf("%lf", &num);

    num2 = (int)(num) % 10;

    printf("%d", num2);

    return 0;
}*/