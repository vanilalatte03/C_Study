//���빮�� 4-2

#include <stdio.h>

int main(void) {
	char star1 = "*";
	char star2 = "***";
	char star3 = "*****";
	char star4 = "*******";

	printf("%3c\n", star1);
	printf("%2c\n", star2);
	printf("%1c\n", star3);
	printf("%c\n", star4);

	return 0;
}
