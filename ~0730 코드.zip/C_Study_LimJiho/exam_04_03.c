//���� 4-3_printf �Լ��� ���� ����
/*
#include <stdio.h>

int main(void) {
	char charater = 'X';
	int inumber = 92;
	double dnumber = 20.201005;

	printf("%c\n", charater);
	printf("%d\n", charater);
	printf("%d\n", inumber);
	printf("%x\n", inumber);
	printf("%o\n", inumber);
	printf("%f\n", dnumber);
	printf("%e\n", dnumber);

	return 0;
}*/